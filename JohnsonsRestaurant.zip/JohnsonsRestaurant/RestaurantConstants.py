DATABASE_NAME = "inventory"
DATABASE_TABLE = "food"
COLUMN_ITEM = "item"
COLUMN_QUANTITY = "quantity"